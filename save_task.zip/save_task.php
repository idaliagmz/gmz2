<?php

include('db.php');

if (isset($_POST['save_task'])) {
  $foliocompra = $_POST['folio_compra'];
  $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
  $query = "INSERT INTO compras(folio_compra, descripcion_producto,precio,fecha_de_compra,cantidad_de_compra,tipo_de_cambio,sucursal) VALUES ('$foliocompra', '$description',)";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'Task Saved Successfully';
  $_SESSION['message_type'] = 'success';
  header('Location: index.php');

}

?>
